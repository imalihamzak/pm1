"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "app/api/auth/[...nextauth]/route";
exports.ids = ["app/api/auth/[...nextauth]/route"];
exports.modules = {

/***/ "./action-async-storage.external":
/*!*******************************************************************************!*\
  !*** external "next/dist/client/components/action-async-storage.external.js" ***!
  \*******************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/client/components/action-async-storage.external.js");

/***/ }),

/***/ "./request-async-storage.external":
/*!********************************************************************************!*\
  !*** external "next/dist/client/components/request-async-storage.external.js" ***!
  \********************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/client/components/request-async-storage.external.js");

/***/ }),

/***/ "./static-generation-async-storage.external":
/*!******************************************************************************************!*\
  !*** external "next/dist/client/components/static-generation-async-storage.external.js" ***!
  \******************************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/client/components/static-generation-async-storage.external.js");

/***/ }),

/***/ "next/dist/compiled/next-server/app-page.runtime.dev.js":
/*!*************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-page.runtime.dev.js" ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-page.runtime.dev.js");

/***/ }),

/***/ "next/dist/compiled/next-server/app-route.runtime.dev.js":
/*!**************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-route.runtime.dev.js" ***!
  \**************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-route.runtime.dev.js");

/***/ }),

/***/ "assert":
/*!*************************!*\
  !*** external "assert" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("assert");

/***/ }),

/***/ "buffer":
/*!*************************!*\
  !*** external "buffer" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("buffer");

/***/ }),

/***/ "crypto":
/*!*************************!*\
  !*** external "crypto" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ "events":
/*!*************************!*\
  !*** external "events" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("events");

/***/ }),

/***/ "http":
/*!***********************!*\
  !*** external "http" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("http");

/***/ }),

/***/ "https":
/*!************************!*\
  !*** external "https" ***!
  \************************/
/***/ ((module) => {

module.exports = require("https");

/***/ }),

/***/ "querystring":
/*!******************************!*\
  !*** external "querystring" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("querystring");

/***/ }),

/***/ "url":
/*!**********************!*\
  !*** external "url" ***!
  \**********************/
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("util");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("zlib");

/***/ }),

/***/ "(rsc)/../node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute&page=%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute.ts&appDir=C%3A%5CUsers%5CThis%20PC%5CDownloads%5Cnew-project-main%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5CThis%20PC%5CDownloads%5Cnew-project-main&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!":
/*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute&page=%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute.ts&appDir=C%3A%5CUsers%5CThis%20PC%5CDownloads%5Cnew-project-main%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5CThis%20PC%5CDownloads%5Cnew-project-main&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D! ***!
  \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   originalPathname: () => (/* binding */ originalPathname),\n/* harmony export */   patchFetch: () => (/* binding */ patchFetch),\n/* harmony export */   requestAsyncStorage: () => (/* binding */ requestAsyncStorage),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   serverHooks: () => (/* binding */ serverHooks),\n/* harmony export */   staticGenerationAsyncStorage: () => (/* binding */ staticGenerationAsyncStorage)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/future/route-modules/app-route/module.compiled */ \"(rsc)/../node_modules/next/dist/server/future/route-modules/app-route/module.compiled.js\");\n/* harmony import */ var next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/future/route-kind */ \"(rsc)/../node_modules/next/dist/server/future/route-kind.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/server/lib/patch-fetch */ \"(rsc)/../node_modules/next/dist/server/lib/patch-fetch.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var C_Users_This_PC_Downloads_new_project_main_app_api_auth_nextauth_route_ts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app/api/auth/[...nextauth]/route.ts */ \"(rsc)/./app/api/auth/[...nextauth]/route.ts\");\n\n\n\n\n// We inject the nextConfigOutput here so that we can use them in the route\n// module.\nconst nextConfigOutput = \"\"\nconst routeModule = new next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppRouteRouteModule({\n    definition: {\n        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_ROUTE,\n        page: \"/api/auth/[...nextauth]/route\",\n        pathname: \"/api/auth/[...nextauth]\",\n        filename: \"route\",\n        bundlePath: \"app/api/auth/[...nextauth]/route\"\n    },\n    resolvedPagePath: \"C:\\\\Users\\\\This PC\\\\Downloads\\\\new-project-main\\\\app\\\\api\\\\auth\\\\[...nextauth]\\\\route.ts\",\n    nextConfigOutput,\n    userland: C_Users_This_PC_Downloads_new_project_main_app_api_auth_nextauth_route_ts__WEBPACK_IMPORTED_MODULE_3__\n});\n// Pull out the exports that we need to expose from the module. This should\n// be eliminated when we've moved the other routes to the new format. These\n// are used to hook into the route.\nconst { requestAsyncStorage, staticGenerationAsyncStorage, serverHooks } = routeModule;\nconst originalPathname = \"/api/auth/[...nextauth]/route\";\nfunction patchFetch() {\n    return (0,next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__.patchFetch)({\n        serverHooks,\n        staticGenerationAsyncStorage\n    });\n}\n\n\n//# sourceMappingURL=app-route.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi4vbm9kZV9tb2R1bGVzL25leHQvZGlzdC9idWlsZC93ZWJwYWNrL2xvYWRlcnMvbmV4dC1hcHAtbG9hZGVyLmpzP25hbWU9YXBwJTJGYXBpJTJGYXV0aCUyRiU1Qi4uLm5leHRhdXRoJTVEJTJGcm91dGUmcGFnZT0lMkZhcGklMkZhdXRoJTJGJTVCLi4ubmV4dGF1dGglNUQlMkZyb3V0ZSZhcHBQYXRocz0mcGFnZVBhdGg9cHJpdmF0ZS1uZXh0LWFwcC1kaXIlMkZhcGklMkZhdXRoJTJGJTVCLi4ubmV4dGF1dGglNUQlMkZyb3V0ZS50cyZhcHBEaXI9QyUzQSU1Q1VzZXJzJTVDVGhpcyUyMFBDJTVDRG93bmxvYWRzJTVDbmV3LXByb2plY3QtbWFpbiU1Q2FwcCZwYWdlRXh0ZW5zaW9ucz10c3gmcGFnZUV4dGVuc2lvbnM9dHMmcGFnZUV4dGVuc2lvbnM9anN4JnBhZ2VFeHRlbnNpb25zPWpzJnJvb3REaXI9QyUzQSU1Q1VzZXJzJTVDVGhpcyUyMFBDJTVDRG93bmxvYWRzJTVDbmV3LXByb2plY3QtbWFpbiZpc0Rldj10cnVlJnRzY29uZmlnUGF0aD10c2NvbmZpZy5qc29uJmJhc2VQYXRoPSZhc3NldFByZWZpeD0mbmV4dENvbmZpZ091dHB1dD0mcHJlZmVycmVkUmVnaW9uPSZtaWRkbGV3YXJlQ29uZmlnPWUzMCUzRCEiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O0FBQXNHO0FBQ3ZDO0FBQ2M7QUFDd0M7QUFDckg7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLGdIQUFtQjtBQUMzQztBQUNBLGNBQWMseUVBQVM7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLFlBQVk7QUFDWixDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0EsUUFBUSxpRUFBaUU7QUFDekU7QUFDQTtBQUNBLFdBQVcsNEVBQVc7QUFDdEI7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUN1SDs7QUFFdkgiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9wcm9qZWN0LW1hbmFnZW1lbnQtc3lzdGVtLz81Y2Y2Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFwcFJvdXRlUm91dGVNb2R1bGUgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9mdXR1cmUvcm91dGUtbW9kdWxlcy9hcHAtcm91dGUvbW9kdWxlLmNvbXBpbGVkXCI7XG5pbXBvcnQgeyBSb3V0ZUtpbmQgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9mdXR1cmUvcm91dGUta2luZFwiO1xuaW1wb3J0IHsgcGF0Y2hGZXRjaCBhcyBfcGF0Y2hGZXRjaCB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL2xpYi9wYXRjaC1mZXRjaFwiO1xuaW1wb3J0ICogYXMgdXNlcmxhbmQgZnJvbSBcIkM6XFxcXFVzZXJzXFxcXFRoaXMgUENcXFxcRG93bmxvYWRzXFxcXG5ldy1wcm9qZWN0LW1haW5cXFxcYXBwXFxcXGFwaVxcXFxhdXRoXFxcXFsuLi5uZXh0YXV0aF1cXFxccm91dGUudHNcIjtcbi8vIFdlIGluamVjdCB0aGUgbmV4dENvbmZpZ091dHB1dCBoZXJlIHNvIHRoYXQgd2UgY2FuIHVzZSB0aGVtIGluIHRoZSByb3V0ZVxuLy8gbW9kdWxlLlxuY29uc3QgbmV4dENvbmZpZ091dHB1dCA9IFwiXCJcbmNvbnN0IHJvdXRlTW9kdWxlID0gbmV3IEFwcFJvdXRlUm91dGVNb2R1bGUoe1xuICAgIGRlZmluaXRpb246IHtcbiAgICAgICAga2luZDogUm91dGVLaW5kLkFQUF9ST1VURSxcbiAgICAgICAgcGFnZTogXCIvYXBpL2F1dGgvWy4uLm5leHRhdXRoXS9yb3V0ZVwiLFxuICAgICAgICBwYXRobmFtZTogXCIvYXBpL2F1dGgvWy4uLm5leHRhdXRoXVwiLFxuICAgICAgICBmaWxlbmFtZTogXCJyb3V0ZVwiLFxuICAgICAgICBidW5kbGVQYXRoOiBcImFwcC9hcGkvYXV0aC9bLi4ubmV4dGF1dGhdL3JvdXRlXCJcbiAgICB9LFxuICAgIHJlc29sdmVkUGFnZVBhdGg6IFwiQzpcXFxcVXNlcnNcXFxcVGhpcyBQQ1xcXFxEb3dubG9hZHNcXFxcbmV3LXByb2plY3QtbWFpblxcXFxhcHBcXFxcYXBpXFxcXGF1dGhcXFxcWy4uLm5leHRhdXRoXVxcXFxyb3V0ZS50c1wiLFxuICAgIG5leHRDb25maWdPdXRwdXQsXG4gICAgdXNlcmxhbmRcbn0pO1xuLy8gUHVsbCBvdXQgdGhlIGV4cG9ydHMgdGhhdCB3ZSBuZWVkIHRvIGV4cG9zZSBmcm9tIHRoZSBtb2R1bGUuIFRoaXMgc2hvdWxkXG4vLyBiZSBlbGltaW5hdGVkIHdoZW4gd2UndmUgbW92ZWQgdGhlIG90aGVyIHJvdXRlcyB0byB0aGUgbmV3IGZvcm1hdC4gVGhlc2Vcbi8vIGFyZSB1c2VkIHRvIGhvb2sgaW50byB0aGUgcm91dGUuXG5jb25zdCB7IHJlcXVlc3RBc3luY1N0b3JhZ2UsIHN0YXRpY0dlbmVyYXRpb25Bc3luY1N0b3JhZ2UsIHNlcnZlckhvb2tzIH0gPSByb3V0ZU1vZHVsZTtcbmNvbnN0IG9yaWdpbmFsUGF0aG5hbWUgPSBcIi9hcGkvYXV0aC9bLi4ubmV4dGF1dGhdL3JvdXRlXCI7XG5mdW5jdGlvbiBwYXRjaEZldGNoKCkge1xuICAgIHJldHVybiBfcGF0Y2hGZXRjaCh7XG4gICAgICAgIHNlcnZlckhvb2tzLFxuICAgICAgICBzdGF0aWNHZW5lcmF0aW9uQXN5bmNTdG9yYWdlXG4gICAgfSk7XG59XG5leHBvcnQgeyByb3V0ZU1vZHVsZSwgcmVxdWVzdEFzeW5jU3RvcmFnZSwgc3RhdGljR2VuZXJhdGlvbkFzeW5jU3RvcmFnZSwgc2VydmVySG9va3MsIG9yaWdpbmFsUGF0aG5hbWUsIHBhdGNoRmV0Y2gsICB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1hcHAtcm91dGUuanMubWFwIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/../node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute&page=%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute.ts&appDir=C%3A%5CUsers%5CThis%20PC%5CDownloads%5Cnew-project-main%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5CThis%20PC%5CDownloads%5Cnew-project-main&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!\n");

/***/ }),

/***/ "(rsc)/./app/api/auth/[...nextauth]/route.ts":
/*!*********************************************!*\
  !*** ./app/api/auth/[...nextauth]/route.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   GET: () => (/* binding */ handler),\n/* harmony export */   POST: () => (/* binding */ handler)\n/* harmony export */ });\n/* harmony import */ var _lib_nextauth_init__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/lib/nextauth-init */ \"(rsc)/./lib/nextauth-init.ts\");\n/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next-auth */ \"(rsc)/../node_modules/next-auth/index.js\");\n/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_auth__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _lib_auth_config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/lib/auth-config */ \"(rsc)/./lib/auth-config.ts\");\n// Import initialization FIRST - this sets environment variables\n\n\n\nconst handler = next_auth__WEBPACK_IMPORTED_MODULE_1___default()(_lib_auth_config__WEBPACK_IMPORTED_MODULE_2__.authOptions);\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9hcHAvYXBpL2F1dGgvWy4uLm5leHRhdXRoXS9yb3V0ZS50cyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQSxnRUFBZ0U7QUFDbkM7QUFDSTtBQUNlO0FBRWhELE1BQU1FLFVBQVVGLGdEQUFRQSxDQUFDQyx5REFBV0E7QUFDTyIsInNvdXJjZXMiOlsid2VicGFjazovL3Byb2plY3QtbWFuYWdlbWVudC1zeXN0ZW0vLi9hcHAvYXBpL2F1dGgvWy4uLm5leHRhdXRoXS9yb3V0ZS50cz9jOGE0Il0sInNvdXJjZXNDb250ZW50IjpbIi8vIEltcG9ydCBpbml0aWFsaXphdGlvbiBGSVJTVCAtIHRoaXMgc2V0cyBlbnZpcm9ubWVudCB2YXJpYWJsZXNcbmltcG9ydCBcIkAvbGliL25leHRhdXRoLWluaXRcIjtcbmltcG9ydCBOZXh0QXV0aCBmcm9tIFwibmV4dC1hdXRoXCI7XG5pbXBvcnQgeyBhdXRoT3B0aW9ucyB9IGZyb20gXCJAL2xpYi9hdXRoLWNvbmZpZ1wiO1xuXG5jb25zdCBoYW5kbGVyID0gTmV4dEF1dGgoYXV0aE9wdGlvbnMpO1xuZXhwb3J0IHsgaGFuZGxlciBhcyBHRVQsIGhhbmRsZXIgYXMgUE9TVCB9O1xuIl0sIm5hbWVzIjpbIk5leHRBdXRoIiwiYXV0aE9wdGlvbnMiLCJoYW5kbGVyIiwiR0VUIiwiUE9TVCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(rsc)/./app/api/auth/[...nextauth]/route.ts\n");

/***/ }),

/***/ "(rsc)/./lib/auth-config.ts":
/*!****************************!*\
  !*** ./lib/auth-config.ts ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   authOptions: () => (/* binding */ authOptions)\n/* harmony export */ });\n/* harmony import */ var _nextauth_init__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./nextauth-init */ \"(rsc)/./lib/nextauth-init.ts\");\n/* harmony import */ var next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next-auth/providers/credentials */ \"(rsc)/../node_modules/next-auth/providers/credentials.js\");\n/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./config */ \"(rsc)/./lib/config.ts\");\n// Import initialization FIRST to set environment variables\n\n\n\nconst authOptions = {\n    providers: [\n        (0,next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_1__[\"default\"])({\n            name: \"Credentials\",\n            credentials: {\n                email: {\n                    label: \"Email\",\n                    type: \"email\"\n                },\n                password: {\n                    label: \"Password\",\n                    type: \"password\"\n                }\n            },\n            async authorize (credentials) {\n                if (!credentials?.email || !credentials?.password) {\n                    return null;\n                }\n                if (credentials.email === \"manager@softechinc.ai\" && credentials.password === \"tech@321#$\") {\n                    return {\n                        id: \"1\",\n                        email: \"manager@softechinc.ai\",\n                        name: \"Manager\"\n                    };\n                }\n                return null;\n            }\n        })\n    ],\n    pages: {\n        signIn: \"/login\"\n    },\n    session: {\n        strategy: \"jwt\"\n    },\n    secret: _config__WEBPACK_IMPORTED_MODULE_2__.config.nextAuthSecret,\n    callbacks: {\n        async jwt ({ token, user }) {\n            if (user) {\n                token.id = user.id;\n            }\n            return token;\n        },\n        async session ({ session, token }) {\n            if (token && session.user) {\n                session.user.id = token.id;\n            }\n            return session;\n        }\n    },\n    debug: false\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9saWIvYXV0aC1jb25maWcudHMiLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUFBLDJEQUEyRDtBQUNsQztBQUV5QztBQUNoQztBQUUzQixNQUFNRSxjQUErQjtJQUMxQ0MsV0FBVztRQUNUSCwyRUFBbUJBLENBQUM7WUFDbEJJLE1BQU07WUFDTkMsYUFBYTtnQkFDWEMsT0FBTztvQkFBRUMsT0FBTztvQkFBU0MsTUFBTTtnQkFBUTtnQkFDdkNDLFVBQVU7b0JBQUVGLE9BQU87b0JBQVlDLE1BQU07Z0JBQVc7WUFDbEQ7WUFDQSxNQUFNRSxXQUFVTCxXQUFXO2dCQUN6QixJQUFJLENBQUNBLGFBQWFDLFNBQVMsQ0FBQ0QsYUFBYUksVUFBVTtvQkFDakQsT0FBTztnQkFDVDtnQkFFQSxJQUNFSixZQUFZQyxLQUFLLEtBQUssMkJBQ3RCRCxZQUFZSSxRQUFRLEtBQUssY0FDekI7b0JBQ0EsT0FBTzt3QkFDTEUsSUFBSTt3QkFDSkwsT0FBTzt3QkFDUEYsTUFBTTtvQkFDUjtnQkFDRjtnQkFDQSxPQUFPO1lBQ1Q7UUFDRjtLQUNEO0lBQ0RRLE9BQU87UUFDTEMsUUFBUTtJQUNWO0lBQ0FDLFNBQVM7UUFDUEMsVUFBVTtJQUNaO0lBQ0FDLFFBQVFmLDJDQUFNQSxDQUFDZ0IsY0FBYztJQUM3QkMsV0FBVztRQUNULE1BQU1DLEtBQUksRUFBRUMsS0FBSyxFQUFFQyxJQUFJLEVBQUU7WUFDdkIsSUFBSUEsTUFBTTtnQkFDUkQsTUFBTVQsRUFBRSxHQUFHVSxLQUFLVixFQUFFO1lBQ3BCO1lBQ0EsT0FBT1M7UUFDVDtRQUNBLE1BQU1OLFNBQVEsRUFBRUEsT0FBTyxFQUFFTSxLQUFLLEVBQUU7WUFDOUIsSUFBSUEsU0FBU04sUUFBUU8sSUFBSSxFQUFFO2dCQUN6QlAsUUFBUU8sSUFBSSxDQUFDVixFQUFFLEdBQUdTLE1BQU1ULEVBQUU7WUFDNUI7WUFDQSxPQUFPRztRQUNUO0lBQ0Y7SUFDQVEsT0FBTztBQUNULEVBQUUiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9wcm9qZWN0LW1hbmFnZW1lbnQtc3lzdGVtLy4vbGliL2F1dGgtY29uZmlnLnRzP2VmZTMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gSW1wb3J0IGluaXRpYWxpemF0aW9uIEZJUlNUIHRvIHNldCBlbnZpcm9ubWVudCB2YXJpYWJsZXNcclxuaW1wb3J0IFwiLi9uZXh0YXV0aC1pbml0XCI7XHJcbmltcG9ydCB7IE5leHRBdXRoT3B0aW9ucyB9IGZyb20gXCJuZXh0LWF1dGhcIjtcclxuaW1wb3J0IENyZWRlbnRpYWxzUHJvdmlkZXIgZnJvbSBcIm5leHQtYXV0aC9wcm92aWRlcnMvY3JlZGVudGlhbHNcIjtcclxuaW1wb3J0IHsgY29uZmlnIH0gZnJvbSBcIi4vY29uZmlnXCI7XHJcblxyXG5leHBvcnQgY29uc3QgYXV0aE9wdGlvbnM6IE5leHRBdXRoT3B0aW9ucyA9IHtcclxuICBwcm92aWRlcnM6IFtcclxuICAgIENyZWRlbnRpYWxzUHJvdmlkZXIoe1xyXG4gICAgICBuYW1lOiBcIkNyZWRlbnRpYWxzXCIsXHJcbiAgICAgIGNyZWRlbnRpYWxzOiB7XHJcbiAgICAgICAgZW1haWw6IHsgbGFiZWw6IFwiRW1haWxcIiwgdHlwZTogXCJlbWFpbFwiIH0sXHJcbiAgICAgICAgcGFzc3dvcmQ6IHsgbGFiZWw6IFwiUGFzc3dvcmRcIiwgdHlwZTogXCJwYXNzd29yZFwiIH0sXHJcbiAgICAgIH0sXHJcbiAgICAgIGFzeW5jIGF1dGhvcml6ZShjcmVkZW50aWFscykge1xyXG4gICAgICAgIGlmICghY3JlZGVudGlhbHM/LmVtYWlsIHx8ICFjcmVkZW50aWFscz8ucGFzc3dvcmQpIHtcclxuICAgICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgICBpZiAoXHJcbiAgICAgICAgICBjcmVkZW50aWFscy5lbWFpbCA9PT0gXCJtYW5hZ2VyQHNvZnRlY2hpbmMuYWlcIiAmJlxyXG4gICAgICAgICAgY3JlZGVudGlhbHMucGFzc3dvcmQgPT09IFwidGVjaEAzMjEjJFwiXHJcbiAgICAgICAgKSB7XHJcbiAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICBpZDogXCIxXCIsXHJcbiAgICAgICAgICAgIGVtYWlsOiBcIm1hbmFnZXJAc29mdGVjaGluYy5haVwiLFxyXG4gICAgICAgICAgICBuYW1lOiBcIk1hbmFnZXJcIixcclxuICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgICB9LFxyXG4gICAgfSksXHJcbiAgXSxcclxuICBwYWdlczoge1xyXG4gICAgc2lnbkluOiBcIi9sb2dpblwiLFxyXG4gIH0sXHJcbiAgc2Vzc2lvbjoge1xyXG4gICAgc3RyYXRlZ3k6IFwiand0XCIsXHJcbiAgfSxcclxuICBzZWNyZXQ6IGNvbmZpZy5uZXh0QXV0aFNlY3JldCxcclxuICBjYWxsYmFja3M6IHtcclxuICAgIGFzeW5jIGp3dCh7IHRva2VuLCB1c2VyIH0pIHtcclxuICAgICAgaWYgKHVzZXIpIHtcclxuICAgICAgICB0b2tlbi5pZCA9IHVzZXIuaWQ7XHJcbiAgICAgIH1cclxuICAgICAgcmV0dXJuIHRva2VuO1xyXG4gICAgfSxcclxuICAgIGFzeW5jIHNlc3Npb24oeyBzZXNzaW9uLCB0b2tlbiB9KSB7XHJcbiAgICAgIGlmICh0b2tlbiAmJiBzZXNzaW9uLnVzZXIpIHtcclxuICAgICAgICBzZXNzaW9uLnVzZXIuaWQgPSB0b2tlbi5pZCBhcyBzdHJpbmc7XHJcbiAgICAgIH1cclxuICAgICAgcmV0dXJuIHNlc3Npb247XHJcbiAgICB9LFxyXG4gIH0sXHJcbiAgZGVidWc6IGZhbHNlLFxyXG59O1xyXG4iXSwibmFtZXMiOlsiQ3JlZGVudGlhbHNQcm92aWRlciIsImNvbmZpZyIsImF1dGhPcHRpb25zIiwicHJvdmlkZXJzIiwibmFtZSIsImNyZWRlbnRpYWxzIiwiZW1haWwiLCJsYWJlbCIsInR5cGUiLCJwYXNzd29yZCIsImF1dGhvcml6ZSIsImlkIiwicGFnZXMiLCJzaWduSW4iLCJzZXNzaW9uIiwic3RyYXRlZ3kiLCJzZWNyZXQiLCJuZXh0QXV0aFNlY3JldCIsImNhbGxiYWNrcyIsImp3dCIsInRva2VuIiwidXNlciIsImRlYnVnIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./lib/auth-config.ts\n");

/***/ }),

/***/ "(rsc)/./lib/config.ts":
/*!***********************!*\
  !*** ./lib/config.ts ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   config: () => (/* binding */ config)\n/* harmony export */ });\n// Hardcoded configuration values\n// Update these values as needed for your deployment\nconst config = {\n    // NextAuth Configuration\n    nextAuthSecret: \"development-secret-key-change-in-production-use-random-string\",\n    nextAuthUrl: \"http://localhost:3000\",\n    // Database Configuration\n    databaseUrl: \"mongodb+srv://imalishahzadk:imalihamzak@cluster0.yxiquws.mongodb.net/pm?retryWrites=true&w=majority\",\n    // SMTP Configuration\n    smtp: {\n        host: \"softechinc.ai\",\n        port: 465,\n        user: \"noreply@softechinc.ai\",\n        pass: \"y&S@!UoK83&S\"\n    }\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9saWIvY29uZmlnLnRzIiwibWFwcGluZ3MiOiI7Ozs7QUFBQSxpQ0FBaUM7QUFDakMsb0RBQW9EO0FBRTdDLE1BQU1BLFNBQVM7SUFDcEIseUJBQXlCO0lBQ3pCQyxnQkFBZ0I7SUFDaEJDLGFBQWE7SUFFYix5QkFBeUI7SUFDekJDLGFBQWE7SUFFYixxQkFBcUI7SUFDckJDLE1BQU07UUFDSkMsTUFBTTtRQUNOQyxNQUFNO1FBQ05DLE1BQU07UUFDTkMsTUFBTTtJQUNSO0FBQ0YsRUFBRSIsInNvdXJjZXMiOlsid2VicGFjazovL3Byb2plY3QtbWFuYWdlbWVudC1zeXN0ZW0vLi9saWIvY29uZmlnLnRzPzEyODUiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gSGFyZGNvZGVkIGNvbmZpZ3VyYXRpb24gdmFsdWVzXHJcbi8vIFVwZGF0ZSB0aGVzZSB2YWx1ZXMgYXMgbmVlZGVkIGZvciB5b3VyIGRlcGxveW1lbnRcclxuXHJcbmV4cG9ydCBjb25zdCBjb25maWcgPSB7XHJcbiAgLy8gTmV4dEF1dGggQ29uZmlndXJhdGlvblxyXG4gIG5leHRBdXRoU2VjcmV0OiBcImRldmVsb3BtZW50LXNlY3JldC1rZXktY2hhbmdlLWluLXByb2R1Y3Rpb24tdXNlLXJhbmRvbS1zdHJpbmdcIixcclxuICBuZXh0QXV0aFVybDogXCJodHRwOi8vbG9jYWxob3N0OjMwMDBcIiwgLy8gRGVmYXVsdCBmb3IgbG9jYWwgZGV2LCBhdXRvLWRldGVjdGVkIG9uIFZlcmNlbFxyXG5cclxuICAvLyBEYXRhYmFzZSBDb25maWd1cmF0aW9uXHJcbiAgZGF0YWJhc2VVcmw6IFwibW9uZ29kYitzcnY6Ly9pbWFsaXNoYWh6YWRrOmltYWxpaGFtemFrQGNsdXN0ZXIwLnl4aXF1d3MubW9uZ29kYi5uZXQvcG0/cmV0cnlXcml0ZXM9dHJ1ZSZ3PW1ham9yaXR5XCIsXHJcblxyXG4gIC8vIFNNVFAgQ29uZmlndXJhdGlvblxyXG4gIHNtdHA6IHtcclxuICAgIGhvc3Q6IFwic29mdGVjaGluYy5haVwiLFxyXG4gICAgcG9ydDogNDY1LFxyXG4gICAgdXNlcjogXCJub3JlcGx5QHNvZnRlY2hpbmMuYWlcIixcclxuICAgIHBhc3M6IFwieSZTQCFVb0s4MyZTXCIsXHJcbiAgfSxcclxufTtcclxuXHJcbiJdLCJuYW1lcyI6WyJjb25maWciLCJuZXh0QXV0aFNlY3JldCIsIm5leHRBdXRoVXJsIiwiZGF0YWJhc2VVcmwiLCJzbXRwIiwiaG9zdCIsInBvcnQiLCJ1c2VyIiwicGFzcyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(rsc)/./lib/config.ts\n");

/***/ }),

/***/ "(rsc)/./lib/nextauth-init.ts":
/*!******************************!*\
  !*** ./lib/nextauth-init.ts ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   initNextAuth: () => (/* binding */ initNextAuth)\n/* harmony export */ });\n/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./config */ \"(rsc)/./lib/config.ts\");\n// Initialize NextAuth environment variables\n// This file must be imported before any NextAuth code\n\n// Set environment variables if not already set\nif (typeof process !== \"undefined\") {\n    // Set NEXTAUTH_SECRET\n    if (!process.env.NEXTAUTH_SECRET) {\n        process.env.NEXTAUTH_SECRET = _config__WEBPACK_IMPORTED_MODULE_0__.config.nextAuthSecret;\n    }\n    // Set NEXTAUTH_URL\n    if (!process.env.NEXTAUTH_URL) {\n        // Vercel provides VERCEL_URL (without protocol) during runtime\n        // Handle different Vercel URL formats\n        const vercelUrl = process.env.VERCEL_URL;\n        if (vercelUrl) {\n            // VERCEL_URL might be just the domain or include subdomain\n            // Ensure it has protocol\n            if (vercelUrl.startsWith(\"http\")) {\n                process.env.NEXTAUTH_URL = vercelUrl;\n            } else {\n                process.env.NEXTAUTH_URL = `https://${vercelUrl}`;\n            }\n        } else {\n            // Fallback to localhost for development\n            process.env.NEXTAUTH_URL = _config__WEBPACK_IMPORTED_MODULE_0__.config.nextAuthUrl || \"http://localhost:3000\";\n        }\n    }\n}\n// Export a function to ensure this runs\nfunction initNextAuth() {\n    // This function ensures the module is evaluated\n    return true;\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9saWIvbmV4dGF1dGgtaW5pdC50cyIsIm1hcHBpbmdzIjoiOzs7OztBQUFBLDRDQUE0QztBQUM1QyxzREFBc0Q7QUFFcEI7QUFFbEMsK0NBQStDO0FBQy9DLElBQUksT0FBT0MsWUFBWSxhQUFhO0lBQ2xDLHNCQUFzQjtJQUN0QixJQUFJLENBQUNBLFFBQVFDLEdBQUcsQ0FBQ0MsZUFBZSxFQUFFO1FBQ2hDRixRQUFRQyxHQUFHLENBQUNDLGVBQWUsR0FBR0gsMkNBQU1BLENBQUNJLGNBQWM7SUFDckQ7SUFFQSxtQkFBbUI7SUFDbkIsSUFBSSxDQUFDSCxRQUFRQyxHQUFHLENBQUNHLFlBQVksRUFBRTtRQUM3QiwrREFBK0Q7UUFDL0Qsc0NBQXNDO1FBQ3RDLE1BQU1DLFlBQVlMLFFBQVFDLEdBQUcsQ0FBQ0ssVUFBVTtRQUN4QyxJQUFJRCxXQUFXO1lBQ2IsMkRBQTJEO1lBQzNELHlCQUF5QjtZQUN6QixJQUFJQSxVQUFVRSxVQUFVLENBQUMsU0FBUztnQkFDaENQLFFBQVFDLEdBQUcsQ0FBQ0csWUFBWSxHQUFHQztZQUM3QixPQUFPO2dCQUNMTCxRQUFRQyxHQUFHLENBQUNHLFlBQVksR0FBRyxDQUFDLFFBQVEsRUFBRUMsVUFBVSxDQUFDO1lBQ25EO1FBQ0YsT0FBTztZQUNMLHdDQUF3QztZQUN4Q0wsUUFBUUMsR0FBRyxDQUFDRyxZQUFZLEdBQUdMLDJDQUFNQSxDQUFDUyxXQUFXLElBQUk7UUFDbkQ7SUFDRjtBQUNGO0FBRUEsd0NBQXdDO0FBQ2pDLFNBQVNDO0lBQ2QsZ0RBQWdEO0lBQ2hELE9BQU87QUFDVCIsInNvdXJjZXMiOlsid2VicGFjazovL3Byb2plY3QtbWFuYWdlbWVudC1zeXN0ZW0vLi9saWIvbmV4dGF1dGgtaW5pdC50cz9mMWYwIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIEluaXRpYWxpemUgTmV4dEF1dGggZW52aXJvbm1lbnQgdmFyaWFibGVzXHJcbi8vIFRoaXMgZmlsZSBtdXN0IGJlIGltcG9ydGVkIGJlZm9yZSBhbnkgTmV4dEF1dGggY29kZVxyXG5cclxuaW1wb3J0IHsgY29uZmlnIH0gZnJvbSBcIi4vY29uZmlnXCI7XHJcblxyXG4vLyBTZXQgZW52aXJvbm1lbnQgdmFyaWFibGVzIGlmIG5vdCBhbHJlYWR5IHNldFxyXG5pZiAodHlwZW9mIHByb2Nlc3MgIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgLy8gU2V0IE5FWFRBVVRIX1NFQ1JFVFxyXG4gIGlmICghcHJvY2Vzcy5lbnYuTkVYVEFVVEhfU0VDUkVUKSB7XHJcbiAgICBwcm9jZXNzLmVudi5ORVhUQVVUSF9TRUNSRVQgPSBjb25maWcubmV4dEF1dGhTZWNyZXQ7XHJcbiAgfVxyXG4gIFxyXG4gIC8vIFNldCBORVhUQVVUSF9VUkxcclxuICBpZiAoIXByb2Nlc3MuZW52Lk5FWFRBVVRIX1VSTCkge1xyXG4gICAgLy8gVmVyY2VsIHByb3ZpZGVzIFZFUkNFTF9VUkwgKHdpdGhvdXQgcHJvdG9jb2wpIGR1cmluZyBydW50aW1lXHJcbiAgICAvLyBIYW5kbGUgZGlmZmVyZW50IFZlcmNlbCBVUkwgZm9ybWF0c1xyXG4gICAgY29uc3QgdmVyY2VsVXJsID0gcHJvY2Vzcy5lbnYuVkVSQ0VMX1VSTDtcclxuICAgIGlmICh2ZXJjZWxVcmwpIHtcclxuICAgICAgLy8gVkVSQ0VMX1VSTCBtaWdodCBiZSBqdXN0IHRoZSBkb21haW4gb3IgaW5jbHVkZSBzdWJkb21haW5cclxuICAgICAgLy8gRW5zdXJlIGl0IGhhcyBwcm90b2NvbFxyXG4gICAgICBpZiAodmVyY2VsVXJsLnN0YXJ0c1dpdGgoJ2h0dHAnKSkge1xyXG4gICAgICAgIHByb2Nlc3MuZW52Lk5FWFRBVVRIX1VSTCA9IHZlcmNlbFVybDtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBwcm9jZXNzLmVudi5ORVhUQVVUSF9VUkwgPSBgaHR0cHM6Ly8ke3ZlcmNlbFVybH1gO1xyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICAvLyBGYWxsYmFjayB0byBsb2NhbGhvc3QgZm9yIGRldmVsb3BtZW50XHJcbiAgICAgIHByb2Nlc3MuZW52Lk5FWFRBVVRIX1VSTCA9IGNvbmZpZy5uZXh0QXV0aFVybCB8fCAnaHR0cDovL2xvY2FsaG9zdDozMDAwJztcclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcbi8vIEV4cG9ydCBhIGZ1bmN0aW9uIHRvIGVuc3VyZSB0aGlzIHJ1bnNcclxuZXhwb3J0IGZ1bmN0aW9uIGluaXROZXh0QXV0aCgpIHtcclxuICAvLyBUaGlzIGZ1bmN0aW9uIGVuc3VyZXMgdGhlIG1vZHVsZSBpcyBldmFsdWF0ZWRcclxuICByZXR1cm4gdHJ1ZTtcclxufVxyXG5cclxuIl0sIm5hbWVzIjpbImNvbmZpZyIsInByb2Nlc3MiLCJlbnYiLCJORVhUQVVUSF9TRUNSRVQiLCJuZXh0QXV0aFNlY3JldCIsIk5FWFRBVVRIX1VSTCIsInZlcmNlbFVybCIsIlZFUkNFTF9VUkwiLCJzdGFydHNXaXRoIiwibmV4dEF1dGhVcmwiLCJpbml0TmV4dEF1dGgiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/./lib/nextauth-init.ts\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/next-auth","vendor-chunks/@babel","vendor-chunks/jose","vendor-chunks/openid-client","vendor-chunks/uuid","vendor-chunks/oauth","vendor-chunks/@panva","vendor-chunks/yallist","vendor-chunks/preact-render-to-string","vendor-chunks/preact","vendor-chunks/oidc-token-hash","vendor-chunks/cookie"], () => (__webpack_exec__("(rsc)/../node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute&page=%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Fauth%2F%5B...nextauth%5D%2Froute.ts&appDir=C%3A%5CUsers%5CThis%20PC%5CDownloads%5Cnew-project-main%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5CThis%20PC%5CDownloads%5Cnew-project-main&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!")));
module.exports = __webpack_exports__;

})();